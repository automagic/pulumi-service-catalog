import { c as create_ssr_component, d as each, v as validate_component, e as escape } from './ssr-vVkKLCDq.js';

const css$1 = {
  code: ".catalog-item.svelte-1que67q{border:1px solid grey;padding:2rem;width:50%;margin:1rem;border-radius:10px}.catalog-details.svelte-1que67q{display:flex;justify-content:space-between}",
  map: null
};
const CatalogDisplay = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { item } = $$props;
  if ($$props.item === void 0 && $$bindings.item && item !== void 0)
    $$bindings.item(item);
  $$result.css.add(css$1);
  return `<div class="catalog-item svelte-1que67q"><p>Name: <b>${escape(item.name)}</b></p> <p>Description: <b>${escape(item.description)}</b></p> <div class="catalog-details svelte-1que67q"><span>Repository url : <b>${escape(item.repository_url)}</b></span> <span>Branch: <b>${escape(item.branch)}</b></span></div> </div>`;
});
const css = {
  code: ".catalog-page.svelte-11ej90a{padding:2rem 4rem;display:flex;align-items:center;flex-direction:column;justify-content:center}",
  map: null
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  const prerender = true;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  if ($$props.prerender === void 0 && $$bindings.prerender && prerender !== void 0)
    $$bindings.prerender(prerender);
  $$result.css.add(css);
  return `<div class="catalog-page svelte-11ej90a"><h1 data-svelte-h="svelte-u8yws2">Service Catalog</h1> ${each(data.items, (item) => {
    return `${validate_component(CatalogDisplay, "CatalogDisplay").$$render($$result, { item }, {}, {})}`;
  })} </div>`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-nTfzQBMy.js.map
