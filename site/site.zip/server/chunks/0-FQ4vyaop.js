const index = 0;
let component_cache;
const component = async () => component_cache ??= (await import('./layout.svelte-6tikRXIf.js')).default;
const imports = ["_app/immutable/nodes/0.V6-Z8AW8.js","_app/immutable/chunks/scheduler.zMJaRgub.js","_app/immutable/chunks/index.wi2rPaqx.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=0-FQ4vyaop.js.map
