const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./error.svelte-Cp_s7qHF.js')).default;
const imports = ["_app/immutable/nodes/1.gpISyQsY.js","_app/immutable/chunks/scheduler.zMJaRgub.js","_app/immutable/chunks/index.wi2rPaqx.js","_app/immutable/chunks/entry.QW8OKB3e.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-HBLZ4lzM.js.map
