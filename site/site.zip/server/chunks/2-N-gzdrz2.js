const catalog = [
  {
    name: "aws-cs-webserver",
    description: "Autoscaling webserver implementation",
    repository_url: "https://github.com/automagic/aws-cs-webserver.git",
    branch: "main"
  },
  {
    name: "aws-vpc-sared",
    description: "Shared VPC infrastructure",
    repository_url: "https://github.com/pulumi-initech/aws-vpc-shared.git",
    branch: "main"
  }
];
const items = catalog;
const load = () => {
  return {
    items
  };
};

var _page_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-nTfzQBMy.js')).default;
const server_id = "src/routes/+page.server.ts";
const imports = ["_app/immutable/nodes/2.-imC4YsJ.js","_app/immutable/chunks/scheduler.zMJaRgub.js","_app/immutable/chunks/index.wi2rPaqx.js"];
const stylesheets = ["_app/immutable/assets/2.Ipr1sH_i.css"];
const fonts = [];

export { component, fonts, imports, index, _page_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=2-N-gzdrz2.js.map
