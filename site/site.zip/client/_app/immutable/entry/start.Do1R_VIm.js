import{a as t}from"../chunks/entry.QW8OKB3e.js";export{t as start};
